from const import *


class Player:
    pos = ((WEIGHT - size) / 2, (HEIGHT - size) / 2)  # 窗口坐标
    g = 60
    d = g * dt
    tolerance = 0.2

    def __init__(self, pos, max_speed, acceleration, max_height):
        self.name = '我'
        self.x, self.y = pos
        self.y0 = int(self.y // 1)
        self.chunk = int(self.x // chunk_size[0])
        self.v_x = 0
        self.v_y = 0
        self.a_x = 0
        self.a = acceleration
        self.direction = None
        self.max_speed = max_speed
        self.max_height = max_height
        self.start_v = (2 * self.g * self.max_height) ** 0.5
        self.stop = None
        self.jumping = False

    def __correct(self, *, part):
        match part:
            case 'bottom':
                self.y = self.y0 + 1.0
                self.y0 += 1
            case 'left':
                self.x = self.x0 + 1.0
                self.x0 += 1
            case 'right':
                self.x = float(self.x0)

    def __pass(self, world, pos1, pos2):
        try:
            block1 = world.where(pos1)
            block2 = world.where(pos2)
        except:
            return False
        p1 = True if block1 is None else block1.penetrable
        p2 = True if block2 is None else block2.penetrable
        if p1 and p2:
            return True  # 没有障碍
        else:
            return not (self.__collide(block1) or self.__collide(block2))

    def __collide(self, block):
        try:
            bx = block.pos[0]
            by = block.pos[1]
        except:
            return False
        return (bx <= self.x <= bx + size and by <= self.y <= by + size) or (
                bx <= self.x + size <= bx + size and by <= self.y + size <= by + size) or (
                bx <= self.x <= bx + size and by <= self.y + size <= by + size) or (
                bx <= self.x + size <= bx + size and by <= self.y <= by + size)

    def detect(self, world, *, part):
        match part:
            case 'top':
                if self.y0 == self.y:
                    return self.__pass(world, (self.x0, self.y0), (self.x1, self.y0))
                else:
                    return self.__pass(world, (self.x0, self.y0 + 1), (self.x1, self.y0 + 1))
            case 'bottom':
                if self.y0 == self.y:
                    return self.__pass(world, (self.x0, self.y0 - 1), (self.x1, self.y0 - 1))
                else:
                    return self.__pass(world, (self.x0, self.y0), (self.x1, self.y0))
            case 'left':
                if self.y0 == self.y:
                    return self.__pass(world, (self.x0, self.y0), (self.x0, self.y0))
                else:
                    return self.__pass(world, (self.x0, self.y0), (self.x0, self.y0 + 1))
            case 'right':
                if self.y0 == self.y:
                    return self.__pass(world, (self.x1, self.y0), (self.x1, self.y0))
                else:
                    return self.__pass(world, (self.x1, self.y0), (self.x1, self.y0 + 1))
            case _:
                return True

    def get_pos(self):
        return self.x, self.y

    def update(self, world):
        self.chunk = int(self.x // chunk_size[0])
        self.x0 = int((self.x + self.tolerance) // 1)
        self.x1 = int((self.x + 1 - self.tolerance) // 1)
        self.y0 = int(self.y // 1)
        bottom = self.detect(world, part='bottom')

        if self.jumping:
            self.v_y -= self.d
            if self.v_y < 0 and not bottom:
                self.__correct(part='bottom')
                self.jumping = False
                self.v_y = 0
            elif not self.detect(world, part='top') and self.v_y > 0:
                self.jumping = False
                self.v_y = 0
        elif bottom:
            self.jump(True)

        lrx = self.detect(world, part=self.direction)
        if not lrx:
            self.__correct(part=self.direction)
            if self.stop != None:
                self.reset_x()
        if (self.v_x >= 0 and self.stop == 'left') or (self.v_x <= 0 and self.stop == 'right'):
            self.reset_x()
        self.v_x += self.a_x * dt
        self.x += self.v_x * dt
        self.y += self.v_y * dt

        if self.v_x > self.max_speed:
            self.v_x = self.max_speed
        elif self.v_x < -self.max_speed:
            self.v_x = -self.max_speed

    def move_left(self):
        if self.direction == 'right':
            self.reset_x()
        self.direction = 'left'
        self.a_x = -self.a

    def move_right(self):
        if self.direction == 'left':
            self.reset_x()
        self.direction = 'right'
        self.a_x = self.a

    def stop_left(self):
        if self.direction == 'left':
            self.stop = 'left'
            self.a_x = self.a

    def stop_right(self):
        if self.direction == 'right':
            self.stop = 'right'
            self.a_x = -self.a

    def jump(self, fall=False):
        if not self.jumping:
            self.jumping = True
            if not fall:
                self.v_y = self.start_v

    def reset_x(self):
        self.v_x = 0
        self.a_x = 0
        self.direction = None
        self.stop = None

    def acceleration(self, a):
        self.a = a

    def max_speed(self, speed):
        self.max_speed(speed)

    def max_height(self, height):
        self.max_height(height)

    def draw(self, screen):
        ward(screen, self.name, self.pos)
        ward(screen, f'({self.x0},{self.y0})', (10, 10))


class Health:
    def __init__(self, max_health):
        self.health = max_health
        self.max_health = max_health
        self.color = (255, 0, 0)
        self.dead = False

    def remove(self, amount):
        self.health -= amount
        if self.health <= 0 or amount < 0:
            self.health = 0
            self.dead = True

    def add(self, amount):
        self.health += amount
        if self.health > self.max_health or amount < 0:
            self.health = self.max_health

    def set(self, amount):
        if 0 <= amount <= self.max_health:
            self.health = amount
            if self.health == 0:
                self.dead = True

    def draw(self, screen):
        pass


class Knapsack:
    def __init__(self):
        self.inventory = []
        self.knapsack = np.full((8, 3), None, dtype=object)
        self.size = 20

    def add(self, items):
        pass


class Camera:
    rect = (45, 25)
    offset = (-(rect[0] // 2), rect[1] // 2)
    c1 = (WEIGHT - rect[0] * size) / 2
    c2 = (HEIGHT - rect[1] * size) / 2

    def __init__(self, x, y, scaled=1.0):
        self.x = x
        self.y = y
        self.scaled = scaled

    def get_pos(self):
        return self.x, self.y

    def scale(self, scaled):
        self.scaled = scaled

    def update(self, player):
        self.x = player.x + self.offset[0]
        self.y = player.y + self.offset[1]
