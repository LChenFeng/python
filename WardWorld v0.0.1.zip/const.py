import pygame as pg
import win32api

pg.init()

# 获取屏幕信息
info = pg.display.Info()
# 获取屏幕宽度
WEIGHT = info.current_w
# 获取屏幕高度
HEIGHT = info.current_h
# 计算缩放比例，取最小值
scale = min(WEIGHT / 1360, HEIGHT / 768)
# 计算字体大小
size = round(30 * scale)
# 设置字体颜色
color = (255, 255, 255)
# 设置背景颜色
backcolor = (0, 0, 0)
# 设置字体
font = pg.font.Font('data/Zpix-beta-3.0.2.ttf', size)
# 设置块大小
chunk_size = (48, 128)
# 表示世界中区块的编号范围
edgechunk = (-20, 19)
# 设置x轴边界
edgex = (-960, 959)
# 设置y轴边界
edgey = (-63, 64)
# 定义起点坐标
start = (0, 1)
# 获取屏幕刷新率
fps = win32api.EnumDisplaySettings(None, 0).DisplayFrequency
# 计算刷新时间
dt = 1 / fps


def ward(screen, text, pos):
    t = font.render(text, True, color)
    screen.blit(t, pos)
