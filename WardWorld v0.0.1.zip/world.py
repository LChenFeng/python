import numpy as np
import pickle
import os
from object import Block
from const import *


class Chunk:
    def __init__(self, n, new):
        self.n = n
        self.new = new
        self.blocks = None

    def load(self):
        if self.new:
            self.__form()
            self.save()
        else:
            try:
                with open(f'Chunk/{self.n}.pkl', 'rb') as file:
                    blocks = pickle.load(file)
                self.blocks = np.array(blocks)
            except FileNotFoundError:
                self.new = True
                self.load()

    def unload(self):
        self.blocks = None

    def __form(self):
        self.blocks = np.full((48, 128), None, dtype=object)
        for i in range(chunk_size[0]):
            self.blocks[i, 64] = Block(1, self.n, (i, 64))
            self.blocks[i, 127] = Block(5, self.n, (i, 127))
            for j in range(65, 127):
                match j:
                    case j if j < 73:
                        self.blocks[i, j] = Block(2, self.n, (i, j))
                    case j if j < 97:
                        self.blocks[i, j] = Block(3, self.n, (i, j))
                    case _:
                        self.blocks[i, j] = Block(4, self.n, (i, j))
        self.blocks[1:5, 64:66] = None

    def get_map(self):
        return self.blocks

    def save(self):
        try:
            with open(f'Chunk/{self.n}.pkl', 'wb') as file:
                pickle.dump(self.blocks.tolist(), file)
        except FileNotFoundError:
            os.mkdir('Chunk')
            self.save()

    def update(self, camera):
        np.vectorize(lambda x: x.update(camera) if x is not None else None)(self.blocks)

    def draw(self, screen):
        np.vectorize(lambda x: x.draw(screen) if x is not None else None)(self.blocks)


class World:
    def __init__(self, n, new=False):
        self.new = new
        self.chunks = {i: Chunk(i, new) for i in range(edgechunk[0], edgechunk[1] + 1)}
        self.loading = {i for i in range(n - 1, n + 2)}
        self.load(self.loading)

    def update(self, player, camera):
        loading = {i for i in range(max(player.chunk - 1, edgechunk[0]), min(player.chunk + 2, edgechunk[1] + 1))}
        self.load(loading - self.loading)
        self.unload(self.loading - loading)
        self.loading = loading
        for i in self.loading:
            self.chunks[i].update(camera)

    def load(self, n):
        for i in n:
            if edgechunk[0] <= i <= edgechunk[1]:
                self.chunks[i].load()

    def unload(self, n):
        for i in n:
            if edgechunk[0] <= i <= edgechunk[1]:
                self.chunks[i].unload()

    def where(self, pos):
        x = pos[0]
        w = chunk_size[0]
        n = x // w
        if x >= 0:
            i = x % w
        else:
            i = (x - edgex[0]) % w
        j = edgey[1] - pos[1]
        return self.chunks[n].blocks[i, j]

    def draw(self, screen):
        for i in self.loading:
            self.chunks[i].draw(screen)
