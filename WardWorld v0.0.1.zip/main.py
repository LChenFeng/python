import pygame as pg
import sys
from const import *
from player import *
from world import *
from object import *

pg.init()

pg.display.set_caption('WardWorld')
screen = pg.display.set_mode((WEIGHT, HEIGHT), pg.FULLSCREEN, pg.OPENGL | pg.SRCALPHA)
clock = pg.time.Clock()
world = World(0, True)
player = Player((0, 1), 8, 30, 3.5)
camera = Camera(-22, 13)


def main():
    running = True
    while running:
        for event in pg.event.get():
            match event.type:
                case pg.QUIT:
                    running = False
                case pg.KEYDOWN:
                    match event.key:
                        case 27:
                            running = False
                        case 97:
                            player.move_left()
                        case 100:
                            player.move_right()
                        case 32:
                            player.jump()
                case pg.KEYUP:
                    match event.key:
                        case 97:
                            player.stop_left()
                        case 100:
                            player.stop_right()
        world.update(player, camera)
        player.update(world)
        camera.update(player)
        screen.fill(backcolor)
        player.draw(screen)
        world.draw(screen)
        pg.display.flip()
        clock.tick(fps)
    pg.quit()
    sys.exit()


if __name__ == '__main__':
    main()
