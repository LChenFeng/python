from const import *

# id: (name, color, hardness, penetrable, stackable)
DATA = {
    1: ('草', (0, 0, 0), 1, False, True),
    2: ('土', (0, 0, 0), 2, False, True),
    3: ('石', (0, 0, 0), 3, False, True),
    4: ('岩', (0, 0, 0), 4, False, True),
    5: ('基', (0, 0, 0), -1, False, True),
}


class Block:
    def __init__(self, id, n, ij):
        self.pos = (n * chunk_size[0] + ij[0], edgey[1] - ij[1])
        self.id = id
        data = DATA[id]
        self.name = data[0]
        self.hardness = data[2]
        self.penetrable = data[3]

    def get_spos(self):
        return self.sx, self.sy

    def update(self, camera):
        self.sx = (self.pos[0] - camera.x) * size + camera.c1
        self.sy = -(self.pos[1] - camera.y) * size + camera.c2  # 摄像机坐标转换为窗口坐标：x = x0 + c1; y = -y0 + c2

    def draw(self, screen):
        if self.id != 0 and -size <= self.sx <= WEIGHT and -size <= self.sy <= HEIGHT:
            ward(screen, self.name, (self.sx, self.sy))


class Items:
    def __init__(self, id, quantity=1):
        self.name = DATA[id][0]
        self.stackable = DATA[id][4]
        if self.stackable:
            self.max_quantity = 64
        else:
            self.max_quantity = 1
        self.id = id
        self.quantity = quantity
        self.size = 20
        self.offset = self.size * 0.7
        self.size2 = int(self.size * 0.3)

    def add(self, other):
        amount = min(self.max_quantity - self.quantity, other.quantity)
        self.quantity += amount
        other.quantity -= amount

    def draw(self, screen, pos):
        ward(screen, self.name, pos, self.size)
        if self.quantity > 1:
            ward(screen, str(self.quantity), (pos[0] + self.offset, pos[1] + self.offset), self.size2)
